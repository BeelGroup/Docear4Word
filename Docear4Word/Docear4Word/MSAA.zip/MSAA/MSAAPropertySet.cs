﻿using System;
using System.Drawing;

using Office;

namespace MSAALayer
{
	public class MSAAPropertySet
	{
		readonly IAccessible accessible;

		string name = string.Empty;
		string state = string.Empty;
		string role = string.Empty;
		string value = string.Empty;
		string defaultAction = string.Empty;
		Rectangle location;
		IntPtr handle = IntPtr.Zero;

		public string Name
		{
			get { return name; }
		}

		public string State
		{
			get { return state; }
		}

		public bool IsEnabled
		{
			get { return !State.Contains("unavailable"); }
		}

		public bool IsVisible
		{
			get { return !State.Contains("invisible"); }
		}

		public bool IsExist
		{
			get { return Handle != IntPtr.Zero; }
		}

		public string Role
		{
			get { return role; }
		}

		public string Value
		{
			get { return value; }
		}

		public Rectangle Location
		{
			get { return location; }
		}

		public IntPtr Handle
		{
			get { return handle; }
		}

		public string DefaultAction
		{
			get { return defaultAction; }
		}

		public MSAAPropertySet(IAccessible accessibleObject)
		{
			accessible = accessibleObject;

			if (accessible != null)
			{
				SetAccessibleProperties();
			}
		}

		public void Refresh()
		{
			if (accessible != null)
			{
				SetAccessibleProperties();
			}
		}

		void SetAccessibleProperties()
		{
			//Here we are consuming the COM Exceptions which happens in case 
			//the property/Method we need is not available with IAccessible Object.

			try
			{
				name = accessible.accName[0];
			}
			catch
			{}

			try
			{
				value = accessible.accValue[0];
			}
			catch
			{}

			try
			{
				var stateId = Convert.ToUInt32(accessible.accState[0]);

				state = MSAA.GetStateText(stateId);
			}
			catch
			{}

			try
			{
				var roleId = Convert.ToUInt32(accessible.accRole[0]);

				role = MSAA.GetRoleText(roleId);
			}
			catch
			{}

			handle = MSAA.GetHandle(accessible);

			try
			{
				defaultAction = accessible.accDefaultAction[0];
			}
			catch
			{}

			SetLocation(accessible);
		}

		void SetLocation(IAccessible accObject)
		{
			if (accObject == null) return;

			int x1, y1;
			int width;
			int hieght;

			accObject.accLocation(out x1, out y1, out width, out hieght, 0);

			location = new Rectangle(x1, y1, x1 + width, y1 + hieght);
		}
	}
}
