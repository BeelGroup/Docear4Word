﻿using System;
using System.Collections.Generic;

using Office;

namespace Office2007UIModel
{
    public class MSWordWindow: OfficeUIItem
    {
	    readonly OfficeRibbon ribbon;

        OfficeRibbonPropertyPage propertyPage;

        public Dictionary<string, OfficeToolBar> ToolBars
        {
            get { return propertyPage.ToolBars; }
        }
        
        public MSWordWindow(string name): base(name)
        {
            if (Accessible == null)
            {
                throw new Exception("MS Word window not found with the name : " + name);
            }

            ribbon = new OfficeRibbon(Accessible, "Ribbon", true);
			
            if (ribbon.Accessible == null)
            {
                throw new Exception("Ribbon not found.");
            }
        }

	    public MSWordWindow(OfficeAppType appType, string caption): base(GetClassName(appType), caption)
	    {}

	    public void SelectTab(string name)
        {
            if (!ribbon.Tabs.ContainsKey(name))
            {
                //Just give one more try
                ribbon.ReloadTabs();

                if (!ribbon.Tabs.ContainsKey(name))
                {
                    throw new Exception(name + " Ribbon Tab not found.");
                }
            }

            if (ribbon.Tabs[name].Invoke())
            {
                propertyPage = new OfficeRibbonPropertyPage(ribbon.Accessible, name, MSAALayer.AccessibleUIItemType.PropertyPage, true);
            }
        }
    }
}
