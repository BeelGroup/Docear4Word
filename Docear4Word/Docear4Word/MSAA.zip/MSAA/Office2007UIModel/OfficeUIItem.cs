﻿using System;
using System.Text.RegularExpressions;

using MSAALayer;

using Office;

namespace Office2007UIModel
{
	public class OfficeUIItem: MSAAUIItem
	{
		public OfficeUIItem(string name): base(new Regex(name))
		{}

		public OfficeUIItem(IAccessible accessibleObject): base(accessibleObject)
		{}

		public OfficeUIItem(string className, string caption): base(className, caption)
		{}

		public OfficeUIItem(IAccessible parentAccObject, string name, bool ignoreInvisible): base(parentAccObject, new Regex(name), ignoreInvisible)
		{}

		public OfficeUIItem(IAccessible parentAccObject, string name, AccessibleUIItemType uiItemType, bool ignoreInvisible)
			: base(parentAccObject, new Regex(name), uiItemType, ignoreInvisible)
		{}

		public static string GetClassName(OfficeAppType appType)
		{
			switch (appType)
			{
				case OfficeAppType.MicrosoftWord2007:
					return "OpusApp";

				case OfficeAppType.MicrosoftExcel2007:
					return "XLMAIN";

				case OfficeAppType.MicrosoftOutlook2007:
					return "rctrl_renwnd32";

				case OfficeAppType.MicrosoftPowerPoint2007:
					return "PP12FrameClass";

				default:
					return string.Empty;
			}
		}
	}
}
