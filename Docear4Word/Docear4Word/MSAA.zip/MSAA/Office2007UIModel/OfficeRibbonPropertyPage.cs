﻿using System;
using System.Collections.Generic;

using MSAALayer;

using Office;

namespace Office2007UIModel
{
    public class OfficeRibbonPropertyPage : OfficeUIItem
    {
	    readonly Dictionary<string, OfficeToolBar> toolBars = new Dictionary<string, OfficeToolBar>();

	    public OfficeRibbonPropertyPage(IAccessible accessibleObject): base(accessibleObject)
	    {}

	    public OfficeRibbonPropertyPage(IAccessible parentAccObject, string name, bool ignoreInvisible): base(parentAccObject, name, ignoreInvisible)
        {
            PopulateToolBarsForThisPropertyPage();
        }

        public OfficeRibbonPropertyPage(IAccessible parentAccObject, string name, AccessibleUIItemType uiItemType, bool ignoreInvisible)
            : base(parentAccObject, name, uiItemType, ignoreInvisible)
        {
            PopulateToolBarsForThisPropertyPage();
        }

        public Dictionary<string, OfficeToolBar> ToolBars
        {
            get { return toolBars; }
        }

        void PopulateToolBarsForThisPropertyPage()
        {
            toolBars.Clear();

	        if (Accessible == null) return;

	        foreach (var msaaUIItem in GetAllUIItemsOfType(AccessibleUIItemType.ToolBar, true))
	        {
		        if (!string.IsNullOrEmpty(msaaUIItem.Properties.Name))
		        {
			        toolBars.Add(msaaUIItem.Properties.Name, new OfficeToolBar(msaaUIItem.Accessible));
		        }
	        }
        }

        public void ReloadToolBars()
        {
            PopulateToolBarsForThisPropertyPage();
        }
    }
}
