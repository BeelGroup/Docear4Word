﻿using System;
using System.Collections.Generic;

using MSAALayer;

using Office;

namespace Office2007UIModel
{
    public class OfficeToolBar: OfficeUIItem
    {
	    readonly Dictionary<string, OfficeUIItem> controlList = new Dictionary<string, OfficeUIItem>();

        public OfficeToolBar(IAccessible accessibleObject): base(accessibleObject)
        {
            PopulateControlList();
        }

        public OfficeToolBar(IAccessible parentAccObject, string name, bool ignoreInvisible): base(parentAccObject, name, ignoreInvisible)
        {
            PopulateControlList();
        }

        public OfficeToolBar(IAccessible parentAccObject, string name, AccessibleUIItemType uiItemType, bool ignoreInvisible)
            : base(parentAccObject, name, uiItemType, ignoreInvisible)
        {
            PopulateControlList();
        }

        public Dictionary<string, OfficeUIItem> Controls
        {
            get { return controlList; }
        }

        void PopulateControlList()
        {
            controlList.Clear();

            foreach (var msaaUIItem in GetChildren())
            {
                if (!string.IsNullOrEmpty(msaaUIItem.Properties.Name))
                {
                    controlList.Add(msaaUIItem.Properties.Name, new OfficeUIItem(msaaUIItem.Accessible));
                }
            }
        }

        public void ReloadControls()
        {
            PopulateControlList();
        }
    }
}
