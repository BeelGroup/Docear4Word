﻿using System;

using MSAALayer;

using Office;

namespace Office2007UIModel
{
	public class OfficeRibbonTab: OfficeUIItem
	{
		public OfficeRibbonTab(IAccessible accessibleObject): base(accessibleObject)
		{}

		public OfficeRibbonTab(IAccessible parentAccObject, string name, bool ignoreInvisible): base(parentAccObject, name, ignoreInvisible)
		{}

		public OfficeRibbonTab(IAccessible parentAccObject, string name, AccessibleUIItemType uiItemType, bool ignoreInvisible): base(parentAccObject, name, uiItemType, ignoreInvisible)
		{}
	}
}
