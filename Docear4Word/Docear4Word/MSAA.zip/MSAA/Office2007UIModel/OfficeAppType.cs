﻿using System;

namespace Office2007UIModel
{
    public enum OfficeAppType
    {
        NotDefined,
        MicrosoftWord2007,
        MicrosoftExcel2007,
        MicrosoftOutlook2007,
        MicrosoftPowerPoint2007
    }
}
