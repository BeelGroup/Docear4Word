﻿using System;
using System.Collections.Generic;

using Office;

using MSAALayer;

namespace Office2007UIModel
{
    public class OfficeRibbon: OfficeUIItem
    {
	    readonly Dictionary<string, OfficeRibbonTab> tabList = new Dictionary<string, OfficeRibbonTab>();

	    public OfficeRibbon(IAccessible accObject): base(accObject)
	    {
            PopulateRibbonTabList();
	    }
        
	    public Dictionary<string, OfficeRibbonTab> Tabs
	    {
		    get { return tabList; }
	    }

        public OfficeRibbon(IAccessible parentAccObject, string name, bool ignoreInvisible): base(parentAccObject, name, ignoreInvisible)
        {
            PopulateRibbonTabList();
        }

        public OfficeRibbon(IAccessible parentAccObject, string name, AccessibleUIItemType uiItemType, bool ignoreInvisible)
            : base(parentAccObject, name, uiItemType, ignoreInvisible)
        {
            PopulateRibbonTabList();
        }

        void PopulateRibbonTabList()
        {
            tabList.Clear();

            foreach (var msaaUIItem in GetAllUIItemsOfType(AccessibleUIItemType.PageTab, true))
            {
                if (!string.IsNullOrEmpty(msaaUIItem.Properties.Name))
                {
                    tabList.Add(msaaUIItem.Properties.Name, new OfficeRibbonTab(msaaUIItem.Accessible));
                }
            }
        }

        public void ReloadTabs()
        {
            PopulateRibbonTabList();
        }
    }
}
