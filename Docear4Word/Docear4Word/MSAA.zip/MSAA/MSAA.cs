﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Text;

using Office;

namespace MSAALayer
{
    public class MSAA
    {
        static readonly List<IntPtr> topWindowHwndList = new List<IntPtr>();

	    public static IntPtr GetTopWindow(string wClass, string wCaption)
	    {
		    if (string.IsNullOrEmpty(string.Concat(wClass, wCaption)))
            {
                return (IntPtr)0;
            }
		    
			if (string.IsNullOrEmpty(wClass))
		    {
			    return Win32.FindWindowByCaption((IntPtr)0, wCaption);
		    }
		    
			if (string.IsNullOrEmpty(wCaption))
		    {
			    return Win32.FindWindowByClass(wClass, (IntPtr)0);
		    }

		    return Win32.FindWindow(wClass, wCaption);
	    }

	    public static IAccessible[] GetAccessibleChildren(IAccessible objAccessible)
        {
            int childCount;

            try
            {
                childCount = objAccessible.accChildCount;
            }
            catch
            {
                childCount = 0;
            }

            var accObjects = new IAccessible[childCount];
            var count = 0;

            if (childCount != 0)
            {
                Win32.AccessibleChildren(objAccessible, 0, childCount, accObjects, ref count);
            }

            return accObjects;
        }

        public static IAccessible GetObjectByName(IAccessible objParent, Regex objName, bool ignoreInvisible)
        {
	        if (objParent == null) return null;

	        var children = GetAccessibleChildren(objParent);

	        foreach (var child in children)
	        {
		        string childName = null;
		        var childState = string.Empty;

		        try
		        {
			        childName = child.accName[0];
			        childState = GetStateText(Convert.ToUInt32(child.accState[0]));
		        }
		        catch (Exception)
		        {}

		        if (ignoreInvisible)
		        {
			        if (childName != null && objName.Match(childName).Success && !childState.Contains("invisible")) return child;
		        }
		        else
		        {
			        if (childName != null && objName.Match(childName).Success) return child;
		        }

		        IAccessible objToReturn;

		        if (ignoreInvisible)
		        {
			        if (childState.Contains("invisible")) continue;

			        objToReturn = GetObjectByName(child, objName, true);

			        if (objToReturn != null)
			        {
				        return objToReturn;
			        }
		        }
		        else
		        {
			        objToReturn = GetObjectByName(child, objName, false);

			        if (objToReturn != null)
			        {
				        return objToReturn;
			        }
		        }
	        }

	        return null;
        }

        public static IAccessible GetObjectByNameAndRole(IAccessible objParent, Regex objName, string roleText, bool ignoreInvisible)
        {
	        if (objParent == null) return null;

	        var children = GetAccessibleChildren(objParent);

	        foreach (var child in children)
	        {
		        string childName = null;
		        var childState = string.Empty;
		        var childRole = string.Empty;

		        try
		        {
			        childName = child.accName[0];
			        childState = GetStateText(Convert.ToUInt32(child.accState[0]));
			        childRole = GetRoleText(Convert.ToUInt32(child.accRole[0]));
		        }
		        catch (Exception)
		        {}

		        if (ignoreInvisible)
		        {
			        if (!string.IsNullOrEmpty(childName) && objName.Match(childName).Success && childRole == roleText && !childState.Contains("invisible")) return child;
		        }
		        else
		        {
			        if (!string.IsNullOrEmpty(childName) && objName.Match(childName).Success && childRole == roleText) return child;
		        }

		        IAccessible objToReturn;
		        if (ignoreInvisible)
		        {
			        if (!childState.Contains("invisible"))
			        {
				        objToReturn = GetObjectByNameAndRole(child, objName, roleText, true);

				        if (objToReturn != null)
				        {
					        return objToReturn;
				        }
			        }
		        }
		        else
		        {
			        objToReturn = GetObjectByNameAndRole(child, objName, roleText, false);

			        if (objToReturn != null)
			        {
				        return objToReturn;
			        }
		        }
	        }

	        return null;
        }

        public static void GetAccessibleObjectListByRole(IAccessible objParent, string roleText, ref List<IAccessible> accessibleObjList, bool ignoreInvisible)
        {
	        if (objParent == null) return;

	        var children = GetAccessibleChildren(objParent);

	        foreach (var child in children)
	        {
		        string roleTextInner = null;
		        var childState = string.Empty;

		        try
		        {
			        var roleId = Convert.ToUInt32(child.accRole[0]);

			        roleTextInner = GetRoleText(roleId);
			        childState = GetStateText(Convert.ToUInt32(child.accState[0]));
		        }
		        catch (Exception)
		        {}

		        if (ignoreInvisible)
		        {
			        if (roleTextInner == roleText && !childState.Contains("invisible")) accessibleObjList.Add(child);
		        }
		        else
		        {
			        if (roleTextInner == roleText)
			        {
				        accessibleObjList.Add(child);
			        }
		        }

		        if (ignoreInvisible)
		        {
			        if (!childState.Contains("invisible"))
			        {
				        GetAccessibleObjectListByRole(child, roleText, ref accessibleObjList, true);
			        }
		        }
		        else
		        {
			        GetAccessibleObjectListByRole(child, roleText, ref accessibleObjList, false);
		        }
	        }
        }

        public static IAccessible GetTopWindowAccessibleObject(string className, string caption)
        {
            var handle = GetTopWindow(className, caption);

	        try
	        {
		        return GetAccessibleObjectFromHandle(handle);
	        }
	        catch
	        {}

	        return null;
        }

        public static IAccessible GetTopWindowAccessibleObject(Regex windowName)
        {
            foreach (var accWindowObject in GetTopWindowAccessibleList())
            {
	            try
	            {
		            var accWindowName = accWindowObject.accName[0];

		            if (!string.IsNullOrEmpty(accWindowName))
		            {
			            if (windowName.Match(accWindowObject.accName[0]).Success)
			            {
				            return accWindowObject;
			            }
		            }
	            }
	            catch
	            {}
            }

			return null;
        }

        public static IAccessible GetAccessibleObjectFromHandle(IntPtr hwnd)
        {
            var accObject = new object();
            IAccessible objAccessible = null;

            var guidAccessible = new Guid("{618736E0-3C3D-11CF-810C-00AA00389B71}");

	        if (hwnd != (IntPtr) 0)
	        {
		        Win32.AccessibleObjectFromWindow(hwnd, 0, ref guidAccessible, ref accObject);

		        objAccessible = (IAccessible) accObject;
	        }

	        return objAccessible;
        }

        static IEnumerable<IAccessible> GetTopWindowAccessibleList()
        {
            GetTopWindowList();

            var windowList = new List<IAccessible>();

            foreach (var hwnd in topWindowHwndList)
            {
                windowList.Add(GetAccessibleObjectFromHandle(hwnd));
            }

            return windowList;
        }

        static void GetTopWindowList()
        {
            topWindowHwndList.Clear();

	        Win32.EnumWindows(EnumerateTopWindows, (IntPtr) 0);

        }

        static bool EnumerateTopWindows(IntPtr handle, IntPtr lParam)
        {
            topWindowHwndList.Add(handle);

            return true;
        }

        public static string GetStateText(uint stateID)
        {
            return MSAAState.GetStateText(stateID);
        }

        internal static string GetRoleText(uint roleId)
        {
            const uint MaxLength = 1024;

	        var roleText = new StringBuilder((int) MaxLength);

            Win32.GetRoleText(roleId, roleText, MaxLength);

            return roleText.ToString();
        }

        internal static IntPtr GetHandle(IAccessible _accessible)
        {
            var hwnd = IntPtr.Zero;

            Win32.WindowFromAccessibleObject(_accessible, ref hwnd);

            return hwnd;
        }
    }
}
