﻿using System;

namespace MSAALayer
{
    public enum AccessibleUIItemType
    {
        Client,
        ComboBox,
        Dialog,
        EditableText,
        GridDropDownButton,
        List,
        ListItem,
        MenuBar,
        MenuItem,
        PageTab,
        Pane,
        PropertyPage,
        PushButton,
        SplitButton,
        ToolBar,
        DropDown,
        Window,
        TitleBar,
        ScrollBar,
        Grip
    }

    internal static class MSAARoles
    {
        public const string Client = "client";
        public const string ComboBox = "combo box";
        public const string Dialog = "dialog";
        public const string EditableText = "editable text";
        public const string GridDropDownButton = "grid drop down button";
        public const string List = "list";
        public const string ListItem = "list item";
        public const string MenuBar = "menu bar";
        public const string MenuItem = "menu item";
        public const string PageTab = "page tab";
        public const string Pane = "pane";
        public const string PropertyPage = "property page";
        public const string PushButton = "push button";
        public const string SplitButton = "split button";
        public const string ToolBar = "tool bar";
        public const string DropDown = "drop down";
        public const string Window = "window";
        public const string TitleBar = "title bar";
        public const string ScrolBar = "scroll bar";
        public const string Grip = "grip";

        public static string GetRoleText(AccessibleUIItemType role)
        {
            switch (role)
            {
                case AccessibleUIItemType.Client:
                    return Client;

	            case AccessibleUIItemType.ComboBox:
                    return ComboBox;

                case AccessibleUIItemType.Dialog:
                    return Dialog;

                case AccessibleUIItemType.DropDown:
                    return DropDown;

                case AccessibleUIItemType.EditableText:
                    return EditableText;

                case AccessibleUIItemType.GridDropDownButton:
                    return GridDropDownButton;

                case AccessibleUIItemType.List:
                    return List;

                case AccessibleUIItemType.ListItem:
                    return ListItem;

                case AccessibleUIItemType.MenuBar:
                    return MenuBar;

                case AccessibleUIItemType.MenuItem:
                    return MenuItem;

                case AccessibleUIItemType.PageTab:
                    return PageTab;

                case AccessibleUIItemType.Pane:
                    return Pane;

                case AccessibleUIItemType.PropertyPage:
                    return PropertyPage;

                case AccessibleUIItemType.PushButton:
                    return PushButton;

                case AccessibleUIItemType.SplitButton:
                    return SplitButton;

                case AccessibleUIItemType.TitleBar:
                    return TitleBar;

                case AccessibleUIItemType.ToolBar:
                    return ToolBar;

                case AccessibleUIItemType.Window:
                    return Window;

                case AccessibleUIItemType.ScrollBar:
                    return ScrolBar;

                case AccessibleUIItemType.Grip:
                    return Grip;

                default:
                    return string.Empty;
            }
        }
    }
}
