﻿using System;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Threading;

using Office;

namespace MSAALayer
{
    public class MSAAUIItem
    {
	    const int SearchCycles = 15;
	    const int SearchDuration = 2000;

	    readonly IAccessible me;
	    readonly IAccessible parent;
	    readonly MSAAPropertySet propertySet;

        #region Constructors
        public MSAAUIItem(Regex name)
        {
            for (var searchCycleCount = 0; searchCycleCount < SearchCycles; searchCycleCount++)
            {
                me = MSAA.GetTopWindowAccessibleObject(name);

                if (me == null)
                {
                    Thread.Sleep(SearchDuration);
                }
                else
                {
                    propertySet = new MSAAPropertySet(me);
                    break;
                }
            }
        }

        public MSAAUIItem(string className, string caption)
        {
            for (var searchCycleCount = 0; searchCycleCount < SearchCycles; searchCycleCount++)
            {
                me = MSAA.GetTopWindowAccessibleObject(className, caption);

                if (me == null)
                {
                    Thread.Sleep(SearchDuration);
                }
                else
                {
                    propertySet = new MSAAPropertySet(me);
                    break;
                }
            }
        }

        public MSAAUIItem(IAccessible parentAccObject, Regex name, bool ignoreInvisible)
        {
            for (var searchCycleCount = 0; searchCycleCount < SearchCycles; searchCycleCount++)
            {
                me = MSAA.GetObjectByName(parentAccObject, name, ignoreInvisible);
                parent = parentAccObject;
                
                if (me == null)
                {
                    Thread.Sleep(SearchDuration);
                }
                else
                {
                    propertySet = new MSAAPropertySet(me);
                    break;
                }
            }
            
        }

        public MSAAUIItem(IAccessible parentAccObject, Regex name, AccessibleUIItemType uiItemType, bool ignoreInvisible)
        {
            for (var searchCycleCount = 0; searchCycleCount < SearchCycles; searchCycleCount++)
            {
                me = MSAA.GetObjectByNameAndRole(parentAccObject, name, MSAARoles.GetRoleText(uiItemType), ignoreInvisible);
                parent = parentAccObject;

                if (me == null)
                {
                    Thread.Sleep(SearchDuration);
                }
                else
                {
                    propertySet = new MSAAPropertySet(me);
                    break;
                }
            }
            
            propertySet = new MSAAPropertySet(me);
        }

        public MSAAUIItem(IAccessible accObject)
        {
            me = accObject;
            propertySet = new MSAAPropertySet(me);
        }
        #endregion

        #region Public Properties
        public MSAAPropertySet Properties
        {
            get
            {
                propertySet.Refresh();

                return propertySet;
            }
        }

        public IAccessible Accessible
        {
            get { return me; }
        }

        public IAccessible AccessibleParent
        {
            get { return parent; }
        }
        #endregion
        

        #region Public Methods

        public List<MSAAUIItem> GetChildren()
        {
            var accUiItemList = new List<MSAAUIItem>();
            
            foreach(var accUIObject in MSAA.GetAccessibleChildren(me))
            {
	            accUiItemList.Add(new MSAAUIItem(accUIObject));
            }

            return accUiItemList;
        }

        public List<MSAAUIItem> GetChildren(AccessibleUIItemType uiItemType)
        {
            var accUiItemList = new List<MSAAUIItem>();

            foreach (var accUIObject in MSAA.GetAccessibleChildren(me))
            {
                var accUIItem = new MSAAUIItem(accUIObject);
                
                if(accUIItem.Properties.Role == MSAARoles.GetRoleText(uiItemType))
                {
                    accUiItemList.Add(accUIItem);
                }
            }

            return accUiItemList;
        }

        public List<MSAAUIItem> GetAllUIItemsOfType(AccessibleUIItemType uiItemType, bool ignoreInvisible)
        {
            var accUiItemList = new List<MSAAUIItem>();
            var accObjectList = new List<IAccessible>();

            MSAA.GetAccessibleObjectListByRole(me, MSAARoles.GetRoleText(uiItemType), ref accObjectList, ignoreInvisible);

            foreach (var accUIObject in accObjectList)
            {
                var accUIItem = new MSAAUIItem(accUIObject);

                if (accUIItem.Properties.Role == MSAARoles.GetRoleText(uiItemType))
                {
                    accUiItemList.Add(accUIItem);
                }
            }

            return accUiItemList;
        }

        public bool Invoke()
        {
	        if (me == null) return false;

            bool defaultActionSuccess;

	        try
	        {
		        me.accDoDefaultAction(0);
		        defaultActionSuccess = true;
	        }
	        catch
	        {
		        defaultActionSuccess = false;
	        }

	        return defaultActionSuccess;
        }
        #endregion
    }
}
