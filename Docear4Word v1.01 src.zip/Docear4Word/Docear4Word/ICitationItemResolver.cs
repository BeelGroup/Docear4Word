﻿namespace Docear4Word
{
	public interface ICitationItemResolver
	{
			 
	}
}